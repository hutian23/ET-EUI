﻿using System.IO;

namespace UnityFS
{
    public class StreamFile
    {
        public string path;
        public string fileName;
        public Stream stream;
    }
}
