﻿namespace UnityFS
{
    public class Node
    {
        public long offset;
        public long size;
        public uint flags;
        public string path;
    }
}
